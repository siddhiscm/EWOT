package app.json.com.myjson.model;



public class ProtocalData {

    String pName;
    String pDescription;
    String pNoOfStages;
    String pSuitablePersonality;

    String sName;
    String sPositive;
    String sNegative;
    String saltitude;
    String sMethod;
    String sDescription;

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public String getpDescription() {
        return pDescription;
    }

    public void setpDescription(String pDescription) {
        this.pDescription = pDescription;
    }

    public String getpNoOfStages() {
        return pNoOfStages;
    }

    public void setpNoOfStages(String pNoOfStages) {
        this.pNoOfStages = pNoOfStages;
    }

    public String getpSuitablePersonality() {
        return pSuitablePersonality;
    }

    public void setpSuitablePersonality(String pSuitablePersonality) {
        this.pSuitablePersonality = pSuitablePersonality;
    }

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    public String getsPositive() {
        return sPositive;
    }

    public void setsPositive(String sPositive) {
        this.sPositive = sPositive;
    }

    public String getsNegative() {
        return sNegative;
    }

    public void setsNegative(String sNegative) {
        this.sNegative = sNegative;
    }

    public String getSaltitude() {
        return saltitude;
    }

    public void setSaltitude(String saltitude) {
        this.saltitude = saltitude;
    }

    public String getsMethod() {
        return sMethod;
    }

    public void setsMethod(String sMethod) {
        this.sMethod = sMethod;
    }

    public String getsDescription() {
        return sDescription;
    }

    public void setsDescription(String sDescription) {
        this.sDescription = sDescription;
    }
}
