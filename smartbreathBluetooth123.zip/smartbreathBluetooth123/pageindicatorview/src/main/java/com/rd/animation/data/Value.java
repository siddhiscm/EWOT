package com.rd.animation.data;

public interface Value {/*empty*/}
